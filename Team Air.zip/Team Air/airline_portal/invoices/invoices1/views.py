from django.shortcuts import render, redirect
from ..forms import InvoiceSearchForm
from .models import InvoiceRequest
from ..services import fetch_invoice_pdf

def home(request):
    form = InvoiceSearchForm(request.POST or None)
    context = {"form": form}

    if request.method == "POST" and form.is_valid():
        invoice_request = form.save(commit=False)
        invoice_request.status = "pending"
        invoice_request.save()

        # Call scraper/service
        success, pdf_path = fetch_invoice_pdf(invoice_request)

        if success:
            invoice_request.status = "success"
            invoice_request.pdf_file.name = pdf_path
        else:
            invoice_request.status = "error"
        invoice_request.save()

        return redirect("invoice_list")

    return render(request, "invoices/home.html", context)


def invoice_list(request):
    invoices = InvoiceRequest.objects.all().order_by("-created_at")
    return render(request, "invoices/list.html", {"invoices": invoices})
