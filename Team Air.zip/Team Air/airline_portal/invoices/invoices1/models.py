from django.db import models

class InvoiceRequest(models.Model):
    ticket_number = models.CharField(max_length=20)
    pnr_number = models.CharField(max_length=10, blank=True, null=True)
    first_name = models.CharField(max_length=100, blank=True, null=True)
    last_name = models.CharField(max_length=100, blank=True, null=True)

    created_at = models.DateTimeField(auto_now_add=True)
    status = models.CharField(
        max_length=20,
        choices=[("pending", "Pending"), ("success", "Success"), ("error", "Error")],
        default="pending"
    )
    pdf_file = models.FileField(upload_to="invoices/", blank=True, null=True)

    def __str__(self):
        return f"{self.ticket_number} ({self.pnr_number})"
