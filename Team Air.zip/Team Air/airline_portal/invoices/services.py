import os

def fetch_invoice_pdf(invoice_request):
    """
    TODO: Implement logic to POST data to airline portal and download PDF.
    For now, just simulate success/failure.
    """
    if len(invoice_request.ticket_number) == 13:
        dummy_path = f"invoices/{invoice_request.ticket_number}.pdf"
        with open(f"media/{dummy_path}", "wb") as f:
            f.write(b"%PDF-1.4 Dummy Invoice File")
        return True, dummy_path
    return False, None
