# invoices/views.py
from django.shortcuts import render
from .models import PassengerRecord, PassengerInvoice

def dashboard(request):
    passengers = PassengerRecord.objects.all()
    invoices = PassengerInvoice.objects.all()
    return render(request, "invoices/dashboard.html", {
        "passengers": passengers,
        "invoices": invoices
    })
