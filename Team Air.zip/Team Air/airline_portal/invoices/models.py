# invoices/models.py
from django.db import models

class PassengerRecord(models.Model):
    name = models.CharField(max_length=100)
    download_status = models.CharField(
        max_length=20,
        choices=[("Pending", "Pending"), ("Success", "Success"), ("Error", "Error")],
        default="Pending"
    )
    parse_status = models.CharField(
        max_length=20,
        choices=[("Pending", "Pending"), ("Success", "Success"), ("Error", "Error")],
        default="Pending"
    )

    def __str__(self):
        return self.name


class PassengerInvoice(models.Model):
    passenger = models.ForeignKey(PassengerRecord, on_delete=models.CASCADE)
    invoice_no = models.CharField(max_length=50)
    date = models.DateField()
    airline = models.CharField(max_length=100)
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    gstin = models.CharF
