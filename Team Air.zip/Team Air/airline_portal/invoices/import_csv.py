import csv
from django.core.management.base import BaseCommand
from invoices.models import PassengerInvoice  # instead of Invoice

class Command(BaseCommand):
    help = "Import passenger invoice data from CSV"

    def add_arguments(self, parser):
        parser.add_argument("csv_file", type=str, help="C:\Users\admin\Downloads\data.csv")

    def handle(self, *args, **kwargs):
        csv_file = kwargs["csv_file"]

        with open(csv_file, newline='', encoding='utf-8') as file:
            reader = csv.DictReader(file)
            for row in reader:
                PassengerInvoice.objects.create(
                    PassengerInvoice.objects.create(
    passenger_name=row['PassengerName'],
    invoice_number=row['InvoiceNo'],
    date=row['Date'],
    airline=row['Airline'],
    amount=row['Amount'],
    gstin=row['GSTIN'],
    status=row['Status'],
)

                )
        self.stdout.write(self.style.SUCCESS("CSV data imported successfully!"))
