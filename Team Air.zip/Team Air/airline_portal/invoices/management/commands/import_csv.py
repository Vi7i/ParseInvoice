import csv
from django.core.management.base import BaseCommand
from invoices.models import Invoice


class Command(BaseCommand):
    help = "Import invoice data from a CSV file"

    def add_arguments(self, parser):
        parser.add_argument("csv_file", type=str, help="Path to the CSV file")

    def handle(self, *args, **options):
        csv_file = options["csv_file"]

        with open(csv_file, newline='', encoding="utf-8") as f:
            reader = csv.DictReader(f)
            for row in reader:
                Invoice.objects.create(
                    ticket_number=row.get("ticket_number"),
                    pnr_number=row.get("pnr_number"),
                    first_name=row.get("first_name"),
                    last_name=row.get("last_name"),
                )

        self.stdout.write(self.style.SUCCESS("CSV data imported successfully!"))
